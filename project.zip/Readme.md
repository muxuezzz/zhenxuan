一、解压文件

二、在bash命令行输入`npm install -g serve`

三、接着输入`serve -s dist`
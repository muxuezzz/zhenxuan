//用于项目的logo|标题配置
export default {
  title: '硅谷甄选运营平台',
  logoHidden: true, //是否隐藏logo
}

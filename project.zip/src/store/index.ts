import { createPinia } from 'pinia'
// 创建大仓库
let pinia = createPinia()

export default pinia

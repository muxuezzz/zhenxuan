<!--  -->
<template>
  <div>
    <p>我是路由404</p>
  </div>
</template>

<script setup lang="ts"></script>

<style lang="scss" scoped></style>
